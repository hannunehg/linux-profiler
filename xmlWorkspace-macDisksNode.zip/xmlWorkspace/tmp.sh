#!/bin/bash

. common-hardware-extraction-functions.lib

awkScriptMaker darwinDrivesNodeEnumerator
