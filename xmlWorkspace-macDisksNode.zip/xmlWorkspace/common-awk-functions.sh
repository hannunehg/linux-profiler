 #!/bin/awk
 
function printDisk() {
    print "item=\""key"\" attribute=\"Model\" value=\""value"\" generateHwInventoryXmlRecord; ";
  
    displayname="";
  }
