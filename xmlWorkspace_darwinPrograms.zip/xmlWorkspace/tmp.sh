#!/bin/bash
. programs-node-enumerator.lib
awkScriptMaker darwinProgramsNodeEnumerator
