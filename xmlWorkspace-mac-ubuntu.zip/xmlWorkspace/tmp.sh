#!/bin/bash
export OS="Darwin"
. common-hardware-extraction-functions.lib
. hardware-node-enumerator.lib
#. hw-inventory-node-enumerator.lib
  
#awkScriptMaker macCpuNodeAwkScript
#osTypeNode
#osVersionNode
networkadaptersNode
#networkInfoXml

